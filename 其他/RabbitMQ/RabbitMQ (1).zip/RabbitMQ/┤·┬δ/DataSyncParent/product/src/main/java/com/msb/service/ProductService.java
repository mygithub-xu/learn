package com.msb.service;

//import com.msb.bean.Product;

import com.msb.bean.Product;

/**
 * Created by 金喆
 */
public interface ProductService {

    public int insertProduct(Product product) ;
}
