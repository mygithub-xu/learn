package com.msb.dubbo.service;

import com.msb.bean.Product;

/**
 * Created by 金喆
 */
public interface ProductDubboService {

    public int insertProduct(Product product) ;

}
