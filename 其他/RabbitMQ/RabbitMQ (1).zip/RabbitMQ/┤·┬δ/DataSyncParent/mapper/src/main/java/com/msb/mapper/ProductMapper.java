package com.msb.mapper;

import com.msb.bean.Product;

/**
 * Created by 金喆
 */
public interface ProductMapper {

    public int insertProduct(Product product) ;
}
