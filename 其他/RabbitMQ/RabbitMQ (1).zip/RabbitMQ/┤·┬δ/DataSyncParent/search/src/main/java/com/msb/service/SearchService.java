package com.msb.service;

import com.msb.bean.SearchPojo;

/**
 * Created by 金喆
 */
public interface SearchService {


    public boolean insert(SearchPojo searchPojo) ;
}
