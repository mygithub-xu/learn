package com.mashibing.rabbitmqboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
