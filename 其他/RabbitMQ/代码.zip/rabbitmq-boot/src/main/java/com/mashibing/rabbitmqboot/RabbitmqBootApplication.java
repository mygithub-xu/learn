package com.mashibing.rabbitmqboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(RabbitmqBootApplication.class, args);
    }

}
